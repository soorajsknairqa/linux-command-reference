# Linux Commands Reference
### A native GTK4 / Libadwaita desktop app for Fedora

Browse, search and copy 127+ Linux terminal commands — with descriptions,
flags, usage examples and related-command links — in a clean GNOME-native
three-pane layout.

---

## Requirements

| Package | Fedora install |
|---------|---------------|
| Python 3 | pre-installed |
| python3-gobject | `sudo dnf install python3-gobject` |
| GTK 4 | `sudo dnf install gtk4` |
| Libadwaita | `sudo dnf install libadwaita` |

Or install everything at once:

```bash
sudo dnf install python3-gobject gtk4 libadwaita
```

---

## Run

```bash
bash run.sh
```

The script will:
1. Check / install dependencies automatically
2. Add a **GNOME application shortcut** (`~/.local/share/applications/`)
3. Launch the app

---

## Features

- **Three-pane layout** — category sidebar · command list · detail panel
- **Live search** — filters by name, description or related tags
- **16 categories** — Navigation, Files, Permissions, Process, Network …
- **Per-command detail** — full description, syntax, all flags, code examples
- **One-click copy** — copies the command syntax to clipboard
- **Tag navigation** — click related commands to jump between entries
- **Keyboard friendly** — arrow keys navigate, Ctrl+F focuses search

---

## Files

```
linux-ref-app/
├── run.sh                          ← launch / install script
├── linux-commands-reference.desktop
└── linux_ref/
    ├── __init__.py
    ├── main.py                     ← GTK4 application
    └── commands_data.json          ← 127 commands database
```
