#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  Linux Commands Reference — Fedora installer / launcher
# ─────────────────────────────────────────────────────────────────────────────
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_NAME="Linux Commands Reference"

echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║   $APP_NAME         ║"
echo "  ╚══════════════════════════════════════╝"
echo ""

# ── Check Python 3 ───────────────────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "  ✗  Python 3 not found. Install with: sudo dnf install python3"
    exit 1
fi

# ── Check PyGObject / GTK4 ───────────────────────────────────────────────────
if ! python3 -c "import gi; gi.require_version('Gtk','4.0'); gi.require_version('Adw','1')" 2>/dev/null; then
    echo "  ⚙  Installing GTK4 Python bindings..."
    echo "  (requires sudo — you may be prompted for your password)"
    echo ""
    sudo dnf install -y python3-gobject gtk4 libadwaita
    echo ""
fi

echo "  ✓  Dependencies OK"
echo ""

# ── Install shortcut (optional) ──────────────────────────────────────────────
DESKTOP_TARGET="$HOME/.local/share/applications/linux-commands-reference.desktop"
if [ ! -f "$DESKTOP_TARGET" ]; then
    EXEC_LINE="Exec=python3 $SCRIPT_DIR/linux_ref/main.py"
    sed "s|Exec=.*|$EXEC_LINE|" "$SCRIPT_DIR/linux-commands-reference.desktop" \
        > "$DESKTOP_TARGET"
    echo "  ✓  App shortcut added to GNOME application grid"
    echo "     (search for 'Linux Commands' in Activities)"
    echo ""
fi

# ── Launch ───────────────────────────────────────────────────────────────────
echo "  ▶  Launching..."
echo ""
cd "$SCRIPT_DIR"
exec python3 linux_ref/main.py "$@"
