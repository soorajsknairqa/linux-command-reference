Name:           linux-commands-reference
Version:        1.0.0
Release:        1%{?dist}
Summary:        GTK4 desktop app for browsing 127+ Linux terminal commands

License:        MIT
URL:            https://github.com/example/linux-commands-reference
Source0:        %{name}-%{version}.tar.gz

BuildArch:      noarch

# Runtime dependencies
Requires:       python3
Requires:       python3-gobject
Requires:       gtk4
Requires:       libadwaita

# Build dependencies
BuildRequires:  python3

%description
Linux Commands Reference is a native GTK4/Libadwaita desktop application
for Fedora that lets you browse, search and copy over 127 Linux terminal
commands across 16 categories.

Features:
  - Three-pane GNOME-native layout (categories / list / detail)
  - Live search by name, description, or related tags
  - Full flag listings and syntax-highlighted examples per command
  - One-click clipboard copy
  - Related command navigation via tag links
  - Categories: Navigation, Files, Permissions, Process, Network,
    Text, Search, System, Archive, Disk, Users, Package, Shell,
    SSH/Remote, Misc

%prep
%autosetup

%build
# Pure Python — nothing to compile

%install
# Main application data
install -d %{buildroot}%{_datadir}/%{name}/linux_ref
install -m 644 linux_ref/__init__.py    %{buildroot}%{_datadir}/%{name}/linux_ref/
install -m 644 linux_ref/main.py        %{buildroot}%{_datadir}/%{name}/linux_ref/
install -m 644 linux_ref/commands_data.json %{buildroot}%{_datadir}/%{name}/linux_ref/

# Launcher script → /usr/bin
install -d %{buildroot}%{_bindir}
install -m 755 %{name} %{buildroot}%{_bindir}/%{name}

# Desktop entry → GNOME application grid
install -d %{buildroot}%{_datadir}/applications
install -m 644 %{name}.desktop %{buildroot}%{_datadir}/applications/

# AppStream metainfo → GNOME Software
install -d %{buildroot}%{_datadir}/metainfo
install -m 644 com.linuxref.CommandsReference.metainfo.xml \
    %{buildroot}%{_datadir}/metainfo/

%post
# Update desktop and AppStream caches
update-desktop-database %{_datadir}/applications &>/dev/null || :

%postun
update-desktop-database %{_datadir}/applications &>/dev/null || :

%files
%{_bindir}/%{name}
%{_datadir}/%{name}/
%{_datadir}/applications/%{name}.desktop
%{_datadir}/metainfo/com.linuxref.CommandsReference.metainfo.xml

%changelog
* Fri Mar 14 2026 Builder <builder@localhost> - 1.0.0-1
- Initial RPM package release
- GTK4/Libadwaita native UI
- 127 commands across 16 categories
- Live search, clipboard copy, tag navigation
