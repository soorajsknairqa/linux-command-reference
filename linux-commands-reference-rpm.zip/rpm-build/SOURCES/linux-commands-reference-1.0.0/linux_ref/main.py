#!/usr/bin/env python3
"""
Linux Commands Reference — GTK4/Libadwaita desktop app for Fedora
"""

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Gtk, Adw, GLib, Gdk, Pango
import json
import os
import sys

# ── Data ─────────────────────────────────────────────────────────────────────

DATA_FILE = os.path.join(os.path.dirname(__file__), "commands_data.json")
# Allow override from installed system path
_SYSTEM_DATA = "/usr/share/linux-commands-reference/linux_ref/commands_data.json"
if not os.path.exists(DATA_FILE) and os.path.exists(_SYSTEM_DATA):
    DATA_FILE = _SYSTEM_DATA

CATS = [
    {"id": "all",    "label": "All Commands",  "color": "#58a6ff"},
    {"id": "nav",    "label": "Navigation",    "color": "#3fb950"},
    {"id": "file",   "label": "Files",         "color": "#79c0ff"},
    {"id": "perm",   "label": "Permissions",   "color": "#e3b341"},
    {"id": "proc",   "label": "Process",       "color": "#d2a8ff"},
    {"id": "net",    "label": "Network",       "color": "#ffa657"},
    {"id": "text",   "label": "Text",          "color": "#3fb950"},
    {"id": "search", "label": "Search",        "color": "#f85149"},
    {"id": "sys",    "label": "System",        "color": "#79c0ff"},
    {"id": "arch",   "label": "Archive",       "color": "#e3b341"},
    {"id": "disk",   "label": "Disk",          "color": "#d2a8ff"},
    {"id": "user",   "label": "Users",         "color": "#ffa657"},
    {"id": "pkg",    "label": "Package",       "color": "#3fb950"},
    {"id": "shell",  "label": "Shell",         "color": "#58a6ff"},
    {"id": "ssh",    "label": "SSH/Remote",    "color": "#f85149"},
    {"id": "misc",   "label": "Misc",          "color": "#8b949e"},
]

CAT_MAP   = {c["id"]: c for c in CATS}
CAT_COLOR = {c["id"]: c["color"] for c in CATS}


def load_commands():
    with open(DATA_FILE) as f:
        return json.load(f)


# ── CSS ───────────────────────────────────────────────────────────────────────

CSS = """
/* ── Global ── */
window, .main-box { background-color: #0d1117; }

/* ── Sidebar ── */
.sidebar {
    background-color: #161b22;
    border-right: 1px solid #30363d;
    min-width: 200px;
}

.sidebar-header {
    padding: 16px 16px 12px;
    border-bottom: 1px solid #30363d;
    background-color: #161b22;
}

.app-title {
    font-family: "Sora", "Cantarell", sans-serif;
    font-size: 15px;
    font-weight: 700;
    color: #ffffff;
}

.app-sub {
    font-family: "Cantarell", sans-serif;
    font-size: 11px;
    color: #8b949e;
}

.cat-list row {
    border-radius: 8px;
    margin: 1px 8px;
    padding: 2px 0;
    color: #8b949e;
    font-family: "Cantarell", sans-serif;
    font-size: 13px;
}

.cat-list row:selected {
    background-color: #1c2128;
    color: #c9d1d9;
}

.cat-list row:hover:not(:selected) {
    background-color: rgba(255,255,255,0.04);
}

.cat-dot {
    border-radius: 50%;
    min-width: 8px;
    min-height: 8px;
}

/* ── Search ── */
.search-entry {
    background-color: #161b22;
    border: 1px solid #30363d;
    border-radius: 10px;
    color: #c9d1d9;
    font-family: "JetBrains Mono", "Source Code Pro", monospace;
    font-size: 13px;
    padding: 6px 10px;
    caret-color: #58a6ff;
}

.search-entry:focus {
    border-color: #58a6ff;
    box-shadow: 0 0 0 2px rgba(88,166,255,0.15);
}

/* ── Command list ── */
.content-area {
    background-color: #0d1117;
}

.cmd-listbox {
    background-color: transparent;
}

.cmd-listbox > row {
    background-color: #1c2128;
    border: 1px solid #30363d;
    border-radius: 10px;
    margin: 3px 12px;
    padding: 12px 14px;
    transition: background-color 80ms;
}

.cmd-listbox > row:hover {
    background-color: #21262d;
    border-color: rgba(88,166,255,0.4);
}

.cmd-listbox > row:selected {
    background-color: #1c2128;
    border-color: #58a6ff;
    box-shadow: 0 0 0 1px rgba(88,166,255,0.3);
}

.cmd-name {
    font-family: "JetBrains Mono", "Source Code Pro", monospace;
    font-size: 14px;
    font-weight: 700;
    color: #79c0ff;
}

.cmd-badge {
    font-family: "Cantarell", sans-serif;
    font-size: 9px;
    font-weight: 700;
    color: #8b949e;
    background-color: rgba(255,255,255,0.06);
    border-radius: 10px;
    padding: 2px 8px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.cmd-desc {
    font-family: "Cantarell", sans-serif;
    font-size: 12px;
    color: #8b949e;
}

.cmd-syntax {
    font-family: "JetBrains Mono", "Source Code Pro", monospace;
    font-size: 11px;
    color: #e3b341;
    background-color: rgba(0,0,0,0.4);
    border-radius: 5px;
    padding: 3px 8px;
}

/* ── Detail panel ── */
.detail-panel {
    background-color: #0d1117;
    border-left: 1px solid #30363d;
}

.detail-header {
    background-color: #161b22;
    border-bottom: 1px solid #30363d;
    padding: 20px 24px 16px;
}

.detail-cmd {
    font-family: "JetBrains Mono", "Source Code Pro", monospace;
    font-size: 28px;
    font-weight: 700;
    color: #ffffff;
}

.detail-cat {
    font-family: "Cantarell", sans-serif;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: #8b949e;
}

.detail-body {
    background-color: #0d1117;
}

.section-title {
    font-family: "Cantarell", sans-serif;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 1.2px;
    text-transform: uppercase;
    color: #8b949e;
}

.detail-desc {
    font-family: "Cantarell", sans-serif;
    font-size: 14px;
    line-height: 1.7;
    color: #c9d1d9;
}

.syntax-block {
    font-family: "JetBrains Mono", "Source Code Pro", monospace;
    font-size: 13px;
    color: #e3b341;
    background-color: #0d1117;
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 10px 14px;
}

.flag-text {
    font-family: "JetBrains Mono", "Source Code Pro", monospace;
    font-size: 12px;
    color: #ffa657;
    font-weight: 600;
}

.flag-desc {
    font-family: "Cantarell", sans-serif;
    font-size: 13px;
    color: #c9d1d9;
}

.example-topbar {
    font-family: "JetBrains Mono", "Source Code Pro", monospace;
    font-size: 10px;
    color: #8b949e;
    background-color: rgba(255,255,255,0.04);
    border-bottom: 1px solid #30363d;
    padding: 5px 12px;
    border-radius: 8px 8px 0 0;
}

.example-code {
    font-family: "JetBrains Mono", "Source Code Pro", monospace;
    font-size: 12px;
    color: #c9d1d9;
    background-color: #0d1117;
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 10px 14px;
    line-height: 1.8;
}

.copy-btn {
    background-color: rgba(63,185,80,0.1);
    border: 1px solid rgba(63,185,80,0.3);
    border-radius: 8px;
    color: #3fb950;
    font-family: "JetBrains Mono", monospace;
    font-size: 11px;
    padding: 4px 12px;
}

.copy-btn:hover {
    background-color: rgba(63,185,80,0.2);
}

.tag-btn {
    background-color: #161b22;
    border: 1px solid #30363d;
    border-radius: 8px;
    color: #8b949e;
    font-family: "JetBrains Mono", "Source Code Pro", monospace;
    font-size: 11px;
    padding: 4px 10px;
}

.tag-btn:hover {
    border-color: #79c0ff;
    color: #79c0ff;
}

.count-label {
    font-family: "JetBrains Mono", monospace;
    font-size: 11px;
    font-weight: 600;
    color: #3fb950;
    background-color: rgba(63,185,80,0.1);
    border: 1px solid rgba(63,185,80,0.25);
    border-radius: 20px;
    padding: 2px 10px;
}

.placeholder-box {
    background-color: #0d1117;
}

.placeholder-title {
    font-family: "Cantarell", sans-serif;
    font-size: 16px;
    color: #30363d;
}

.separator-line {
    background-color: #30363d;
    min-height: 1px;
}
"""


# ── Widgets ───────────────────────────────────────────────────────────────────

class CommandRow(Gtk.ListBoxRow):
    def __init__(self, cmd):
        super().__init__()
        self.cmd = cmd
        self.add_css_class("cmd-row")

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.set_margin_start(2)
        box.set_margin_end(2)

        # Top row: name + badge
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        top.set_valign(Gtk.Align.CENTER)

        name_lbl = Gtk.Label(label=cmd["name"])
        name_lbl.add_css_class("cmd-name")
        name_lbl.set_xalign(0)
        color = CAT_COLOR.get(cmd["cat"], "#58a6ff")
        name_lbl.set_markup(
            f'<span foreground="{color}" font_family="JetBrains Mono, Source Code Pro, monospace" '
            f'font_weight="bold" font_size="14000">{GLib.markup_escape_text(cmd["name"])}</span>'
        )
        top.append(name_lbl)

        cat_info = CAT_MAP.get(cmd["cat"], {})
        badge = Gtk.Label(label=cat_info.get("label", cmd["cat"]).upper())
        badge.add_css_class("cmd-badge")
        top.append(badge)

        box.append(top)

        # Description
        desc_short = cmd["desc"].split("—")[0].strip()
        desc_lbl = Gtk.Label(label=desc_short)
        desc_lbl.add_css_class("cmd-desc")
        desc_lbl.set_xalign(0)
        desc_lbl.set_wrap(True)
        desc_lbl.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
        box.append(desc_lbl)

        # Syntax
        syn_lbl = Gtk.Label(label=cmd["syntax"])
        syn_lbl.add_css_class("cmd-syntax")
        syn_lbl.set_xalign(0)
        syn_lbl.set_ellipsize(Pango.EllipsizeMode.END)
        syn_lbl.set_margin_top(2)
        box.append(syn_lbl)

        self.set_child(box)


class DetailPanel(Gtk.ScrolledWindow):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.set_hexpand(True)
        self.set_vexpand(True)
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.add_css_class("detail-panel")

        self._outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.set_child(self._outer)

        self._show_placeholder()

    def _clear(self):
        child = self._outer.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self._outer.remove(child)
            child = nxt

    def _show_placeholder(self):
        self._clear()
        ph = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        ph.add_css_class("placeholder-box")
        ph.set_valign(Gtk.Align.CENTER)
        ph.set_halign(Gtk.Align.CENTER)
        ph.set_vexpand(True)
        ph.set_hexpand(True)

        icon = Gtk.Label()
        icon.set_markup('<span font_family="JetBrains Mono, monospace" '
                        'foreground="#30363d" font_size="48000">$_</span>')
        ph.append(icon)

        lbl = Gtk.Label(label="Select a command to view details")
        lbl.add_css_class("placeholder-title")
        ph.append(lbl)

        self._outer.append(ph)

    def show_command(self, cmd):
        self._clear()
        color = CAT_COLOR.get(cmd["cat"], "#58a6ff")
        cat_label = CAT_MAP.get(cmd["cat"], {}).get("label", cmd["cat"])

        # ── Header ───────────────────────────────────────────────────────────
        header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        header.add_css_class("detail-header")
        header.set_margin_bottom(0)

        cmd_lbl = Gtk.Label()
        cmd_lbl.set_markup(
            f'<span foreground="{color}" font_family="JetBrains Mono, Source Code Pro, monospace" '
            f'font_weight="bold" font_size="28000">{GLib.markup_escape_text(cmd["name"])}</span>'
        )
        cmd_lbl.set_xalign(0)
        header.append(cmd_lbl)

        cat_lbl = Gtk.Label()
        cat_lbl.set_markup(
            f'<span foreground="{color}" font_size="11000" font_weight="bold">'
            f'{GLib.markup_escape_text(cat_label.upper())}</span>'
        )
        cat_lbl.set_xalign(0)
        header.append(cat_lbl)

        self._outer.append(header)

        # ── Body ─────────────────────────────────────────────────────────────
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        body.add_css_class("detail-body")
        body.set_margin_start(24)
        body.set_margin_end(24)
        body.set_margin_top(20)
        body.set_margin_bottom(32)

        # Description
        self._section(body, "Description")
        desc_lbl = Gtk.Label(label=cmd["desc"])
        desc_lbl.add_css_class("detail-desc")
        desc_lbl.set_xalign(0)
        desc_lbl.set_wrap(True)
        desc_lbl.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
        desc_lbl.set_margin_bottom(16)
        body.append(desc_lbl)

        # Syntax
        self._section(body, "Syntax")
        syn_box = Gtk.Box()
        syn_box.add_css_class("syntax-block")
        syn_box.set_margin_bottom(20)
        syn_lbl = Gtk.Label()
        syn_lbl.set_markup(
            f'<span foreground="#e3b341" font_family="JetBrains Mono, monospace" '
            f'font_size="13000">{GLib.markup_escape_text(cmd["syntax"])}</span>'
        )
        syn_lbl.set_xalign(0)
        syn_lbl.set_selectable(True)
        syn_box.append(syn_lbl)
        body.append(syn_box)

        # Options
        if cmd.get("options"):
            self._section(body, "Options & Flags")
            opts_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            opts_box.set_margin_bottom(20)
            for i, opt in enumerate(cmd["options"]):
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
                row.set_margin_top(6)
                row.set_margin_bottom(6)

                flag_lbl = Gtk.Label()
                flag_lbl.set_markup(
                    f'<span foreground="#ffa657" font_family="JetBrains Mono, monospace" '
                    f'font_weight="bold" font_size="12000">'
                    f'{GLib.markup_escape_text(opt["flag"])}</span>'
                )
                flag_lbl.set_xalign(0)
                flag_lbl.set_size_request(130, -1)
                flag_lbl.set_selectable(True)
                row.append(flag_lbl)

                desc_lbl = Gtk.Label(label=opt["desc"])
                desc_lbl.add_css_class("flag-desc")
                desc_lbl.set_xalign(0)
                desc_lbl.set_wrap(True)
                desc_lbl.set_hexpand(True)
                row.append(desc_lbl)

                opts_box.append(row)

                if i < len(cmd["options"]) - 1:
                    sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
                    sep.add_css_class("separator-line")
                    opts_box.append(sep)

            body.append(opts_box)

        # Examples
        if cmd.get("examples"):
            self._section(body, "Examples")
            for ex in cmd["examples"]:
                ex_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
                ex_container.set_margin_bottom(12)

                topbar = Gtk.Label(label=f"bash — {ex['title']}")
                topbar.add_css_class("example-topbar")
                topbar.set_xalign(0)
                ex_container.append(topbar)

                code_lbl = Gtk.Label(label=ex["code"])
                code_lbl.add_css_class("example-code")
                code_lbl.set_xalign(0)
                code_lbl.set_wrap(False)
                code_lbl.set_selectable(True)
                ex_container.append(code_lbl)

                body.append(ex_container)

                # Copy button
                copy_row = Gtk.Box()
                copy_row.set_margin_bottom(8)
                copy_btn = Gtk.Button(label="⎘  Copy syntax")
                copy_btn.add_css_class("copy-btn")
                copy_btn.set_halign(Gtk.Align.START)
                copy_btn.connect("clicked", self._on_copy, cmd["syntax"])
                copy_row.append(copy_btn)
                body.append(copy_row)

        # Related
        if cmd.get("tags"):
            self._section(body, "Related Commands")
            tags_flow = Gtk.FlowBox()
            tags_flow.set_homogeneous(False)
            tags_flow.set_selection_mode(Gtk.SelectionMode.NONE)
            tags_flow.set_margin_top(4)
            tags_flow.set_margin_bottom(8)
            tags_flow.set_column_spacing(6)
            tags_flow.set_row_spacing(6)

            for tag in cmd["tags"]:
                btn = Gtk.Button(label=tag)
                btn.add_css_class("tag-btn")
                btn.connect("clicked", self._on_tag_click, tag)
                tags_flow.append(btn)

            body.append(tags_flow)

        self._outer.append(body)

    def _section(self, parent, title):
        lbl = Gtk.Label(label=title.upper())
        lbl.add_css_class("section-title")
        lbl.set_xalign(0)
        lbl.set_margin_bottom(8)
        parent.append(lbl)

    def _on_copy(self, btn, text):
        display = Gdk.Display.get_default()
        clipboard = display.get_clipboard()
        clipboard.set(text)
        btn.set_label("✓  Copied!")
        GLib.timeout_add(1800, lambda: btn.set_label("⎘  Copy syntax") or False)

    def _on_tag_click(self, btn, tag):
        self.app.search_for(tag)


# ── Main Window ───────────────────────────────────────────────────────────────

class MainWindow(Adw.ApplicationWindow):
    def __init__(self, application):
        super().__init__(application=application)
        self.commands = load_commands()
        self.active_cat = "all"
        self.search_query = ""

        self.set_title("Linux Commands Reference")
        self.set_default_size(1100, 700)
        self.set_size_request(800, 500)

        self._build_ui()
        self._refresh_list()

    def _build_ui(self):
        root = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        root.add_css_class("main-box")
        self.set_content(root)

        # ── Left sidebar ──────────────────────────────────────────────────────
        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        sidebar.add_css_class("sidebar")
        sidebar.set_size_request(210, -1)
        root.append(sidebar)

        # Sidebar header
        hdr = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        hdr.add_css_class("sidebar-header")

        icon_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        icon_lbl = Gtk.Label()
        icon_lbl.set_markup(
            '<span foreground="#3fb950" font_family="JetBrains Mono, monospace" '
            'font_weight="bold" font_size="18000">$_</span>'
        )
        icon_row.append(icon_lbl)

        title_col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        t = Gtk.Label(label="Linux Commands")
        t.add_css_class("app-title")
        t.set_xalign(0)
        title_col.append(t)
        s = Gtk.Label(label="Complete reference")
        s.add_css_class("app-sub")
        s.set_xalign(0)
        title_col.append(s)
        icon_row.append(title_col)

        hdr.append(icon_row)
        sidebar.append(hdr)

        # Category list
        cat_scroll = Gtk.ScrolledWindow()
        cat_scroll.set_vexpand(True)
        cat_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        cat_scroll.set_margin_top(8)
        cat_scroll.set_margin_bottom(8)

        self.cat_listbox = Gtk.ListBox()
        self.cat_listbox.add_css_class("cat-list")
        self.cat_listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.cat_listbox.connect("row-selected", self._on_cat_selected)

        for cat in CATS:
            row = Gtk.ListBoxRow()
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            box.set_margin_start(8)
            box.set_margin_end(8)
            box.set_margin_top(6)
            box.set_margin_bottom(6)

            dot = Gtk.Label()
            dot.set_markup(f'<span foreground="{cat["color"]}" font_size="14000">●</span>')
            box.append(dot)

            lbl = Gtk.Label(label=cat["label"])
            lbl.set_xalign(0)
            lbl.set_hexpand(True)
            box.append(lbl)

            row.set_child(box)
            row._cat_id = cat["id"]
            self.cat_listbox.append(row)

        cat_scroll.set_child(self.cat_listbox)
        sidebar.append(cat_scroll)

        # Select "All" by default
        self.cat_listbox.select_row(self.cat_listbox.get_row_at_index(0))

        # ── Centre: search + command list ─────────────────────────────────────
        centre = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        centre.set_size_request(320, -1)
        centre.set_hexpand(False)
        root.append(centre)

        # Search + count bar
        search_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        search_bar.set_margin_start(12)
        search_bar.set_margin_end(12)
        search_bar.set_margin_top(12)
        search_bar.set_margin_bottom(8)

        self.search_entry = Gtk.SearchEntry()
        self.search_entry.add_css_class("search-entry")
        self.search_entry.set_placeholder_text("Search commands…")
        self.search_entry.set_hexpand(True)
        self.search_entry.connect("search-changed", self._on_search)
        search_bar.append(self.search_entry)

        self.count_lbl = Gtk.Label(label="0")
        self.count_lbl.add_css_class("count-label")
        search_bar.append(self.count_lbl)

        centre.append(search_bar)

        # Command list
        list_scroll = Gtk.ScrolledWindow()
        list_scroll.set_vexpand(True)
        list_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        list_scroll.add_css_class("content-area")

        self.cmd_listbox = Gtk.ListBox()
        self.cmd_listbox.add_css_class("cmd-listbox")
        self.cmd_listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.cmd_listbox.connect("row-selected", self._on_cmd_selected)

        list_scroll.set_child(self.cmd_listbox)
        centre.append(list_scroll)

        # ── Right: detail panel ───────────────────────────────────────────────
        self.detail = DetailPanel(self)
        self.detail.set_hexpand(True)
        root.append(self.detail)

    def _refresh_list(self):
        # Clear
        child = self.cmd_listbox.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.cmd_listbox.remove(child)
            child = nxt

        filtered = self._get_filtered()
        self.count_lbl.set_label(str(len(filtered)))

        for cmd in filtered:
            row = CommandRow(cmd)
            self.cmd_listbox.append(row)

    def _get_filtered(self):
        q = self.search_query.lower()
        result = []
        for cmd in self.commands:
            if self.active_cat != "all" and cmd["cat"] != self.active_cat:
                continue
            if q and not (
                q in cmd["name"] or
                q in cmd["desc"].lower() or
                any(q in t for t in cmd.get("tags", []))
            ):
                continue
            result.append(cmd)
        return result

    def _on_cat_selected(self, lb, row):
        if row is None:
            return
        self.active_cat = row._cat_id
        self._refresh_list()

    def _on_search(self, entry):
        self.search_query = entry.get_text()
        if self.search_query:
            # switch to "All" when searching
            self.active_cat = "all"
            self.cat_listbox.select_row(self.cat_listbox.get_row_at_index(0))
        self._refresh_list()

    def _on_cmd_selected(self, lb, row):
        if row is None:
            self.detail._show_placeholder()
            return
        self.detail.show_command(row.cmd)

    def search_for(self, query):
        """Called by DetailPanel tag clicks."""
        self.search_entry.set_text(query)
        self.search_query = query
        self.active_cat = "all"
        self.cat_listbox.select_row(self.cat_listbox.get_row_at_index(0))
        self._refresh_list()


# ── Application ───────────────────────────────────────────────────────────────

class LinuxRefApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id="com.linuxref.CommandsReference")
        self.connect("activate", self.on_activate)

    def on_activate(self, app):
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(CSS.encode())
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )
        win = MainWindow(application=self)
        win.present()


def main():
    app = LinuxRefApp()
    return app.run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
