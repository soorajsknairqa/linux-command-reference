#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════════
#  Linux Commands Reference — RPM builder
#  Run this script on your Fedora machine to produce the .rpm file
# ══════════════════════════════════════════════════════════════════════════════
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "  ┌──────────────────────────────────────────┐"
echo "  │   Linux Commands Reference — RPM Build   │"
echo "  └──────────────────────────────────────────┘"
echo ""

# ── Install build tools if needed ────────────────────────────────────────────
if ! command -v rpmbuild &>/dev/null; then
    echo "  ⚙  Installing rpm-build tools..."
    sudo dnf install -y rpm-build rpmdevtools
fi

echo "  ✓  rpmbuild available: $(rpmbuild --version)"
echo ""

# ── Set up rpmbuild tree in home directory ────────────────────────────────────
rpmdev-setuptree
RPMBUILD_DIR="$HOME/rpmbuild"

# ── Copy spec and source into rpmbuild tree ───────────────────────────────────
cp "$SCRIPT_DIR/SPECS/linux-commands-reference.spec" \
    "$RPMBUILD_DIR/SPECS/"

cp "$SCRIPT_DIR/SOURCES/linux-commands-reference-1.0.0.tar.gz" \
    "$RPMBUILD_DIR/SOURCES/"

echo "  ✓  Spec and source copied to ~/rpmbuild"
echo ""

# ── Build the RPM ─────────────────────────────────────────────────────────────
echo "  ⚙  Building RPM..."
echo ""
rpmbuild -bb "$RPMBUILD_DIR/SPECS/linux-commands-reference.spec"

# ── Find and report the output ───────────────────────────────────────────────
RPM_FILE=$(find "$RPMBUILD_DIR/RPMS" -name "linux-commands-reference-*.rpm" | head -1)

echo ""
echo "  ╔══════════════════════════════════════════════════════════╗"
echo "  ║   ✓  RPM built successfully!                            ║"
echo "  ╚══════════════════════════════════════════════════════════╝"
echo ""
echo "  File: $RPM_FILE"
echo "  Size: $(du -h "$RPM_FILE" | cut -f1)"
echo ""
echo "  Install with:"
echo "    sudo dnf install \"$RPM_FILE\""
echo ""
echo "  Or:"
echo "    sudo rpm -ivh \"$RPM_FILE\""
echo ""
echo "  Then launch:"
echo "    linux-commands-reference"
echo "  Or search 'Linux Commands' in GNOME Activities"
echo ""

# ── Optionally copy RPM to current directory ─────────────────────────────────
cp "$RPM_FILE" "$SCRIPT_DIR/"
echo "  ✓  RPM also copied to: $SCRIPT_DIR/$(basename "$RPM_FILE")"
echo ""
