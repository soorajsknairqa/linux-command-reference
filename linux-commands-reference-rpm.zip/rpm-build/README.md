# Linux Commands Reference — RPM Package

## Build the RPM (on your Fedora machine)

```bash
bash build-rpm.sh
```

That's it. The script will:
1. Install `rpm-build` + `rpmdevtools` via dnf if needed
2. Set up `~/rpmbuild/` tree automatically
3. Build the `.rpm`
4. Print the exact install command

---

## Install the RPM

```bash
sudo dnf install ./linux-commands-reference-1.0.0-1.fc*.noarch.rpm
```

---

## After installing

Launch from terminal:
```bash
linux-commands-reference
```

Or search **"Linux Commands"** in GNOME Activities (Super key).

---

## Uninstall

```bash
sudo dnf remove linux-commands-reference
```

---

## What gets installed

| Path | Contents |
|------|----------|
| `/usr/bin/linux-commands-reference` | Launcher script |
| `/usr/share/linux-commands-reference/linux_ref/` | Python app + data |
| `/usr/share/applications/linux-commands-reference.desktop` | GNOME app entry |
| `/usr/share/metainfo/com.linuxref.CommandsReference.metainfo.xml` | AppStream info |

---

## RPM dependencies (auto-resolved by dnf)

- `python3`
- `python3-gobject`
- `gtk4`
- `libadwaita`

---

## File layout

```
linux-commands-reference-rpm/
├── build-rpm.sh                   ← run this on Fedora
├── README.md
├── SPECS/
│   └── linux-commands-reference.spec
└── SOURCES/
    └── linux-commands-reference-1.0.0.tar.gz
```
